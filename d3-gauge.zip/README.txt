A Pen created at CodePen.io. You can find this one at https://codepen.io/Serghi0/pen/MQdbjo.

 A d3 gauge visualization using browserify modules pulled from browserify cdn as standalones.
Powered by the d3-gauge module: https://github.com/thlorenz/d3-gauge